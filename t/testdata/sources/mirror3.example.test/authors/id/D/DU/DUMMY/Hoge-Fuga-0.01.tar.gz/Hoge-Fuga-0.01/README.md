# NAME

Hoge::Fuga - It's new $module

# SYNOPSIS

    use Hoge::Fuga;

# DESCRIPTION

Hoge::Fuga is ...

# LICENSE

Copyright (C) karupanerura.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# AUTHOR

karupanerura <karupa@cpan.org>
