# NAME

Foo::Bar - It's new $module

# SYNOPSIS

    use Foo::Bar;

# DESCRIPTION

Foo::Bar is ...

# LICENSE

Copyright (C) karupanerura.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# AUTHOR

karupanerura <karupa@cpan.org>
